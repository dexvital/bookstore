<?php

/* book/edit.html.twig */
class __TwigTemplate_1c7ce3675569a52cc63fffce58e85d3c8e71bd7d5872e048ae0fe76dc36edef0 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("main.html.twig", "book/edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "main.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "book/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
    <br />
    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 6, $this->source); })()), 'form_start', array("action" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("book_edit"), "attr" => array("class" => "form-horizontal")));
        echo "
    ";
        // line 7
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 7, $this->source); })()), 'errors');
        echo "

    <div class=\"row\">
        <div class=\"col-sm-4\">

            <div class=\"form-group row\">
                ";
        // line 13
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 13, $this->source); })()), "name", array()), 'label', array("label_attr" => array("class" => "col-sm-3 col-form-label")));
        echo "
                <div class=\"col-sm-9\">
                    ";
        // line 15
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 15, $this->source); })()), "name", array()), 'widget', array("attr" => array("class" => "form-control")));
        echo "
                </div>
            </div>
            <div class=\"form-group row\">
                ";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 19, $this->source); })()), "price", array()), 'label', array("label_attr" => array("class" => "col-sm-3 col-form-label")));
        echo "
                <div class=\"col-sm-9\">
                    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 21, $this->source); })()), "price", array()), 'widget', array("attr" => array("class" => "form-control", "style" => "width: 100px; display: inline;")));
        echo "
                </div>
            </div>

            ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 25, $this->source); })()), "save", array()), 'widget', array("attr" => array("class" => "btn btn-primary col-sm-offset-3")));
        echo "
        </div>
    </div>


    ";
        // line 30
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["book_form"]) || array_key_exists("book_form", $context) ? $context["book_form"] : (function () { throw new Twig_Error_Runtime('Variable "book_form" does not exist.', 30, $this->source); })()), 'form_end');
        echo "


    <script>
        jQuery( document ).ready(function() {

        });
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "book/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 30,  85 => 25,  78 => 21,  73 => 19,  66 => 15,  61 => 13,  52 => 7,  48 => 6,  44 => 4,  38 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'main.html.twig' %}

{% block content %}

    <br />
    {{ form_start(book_form,{'action' : path('book_edit'),'attr': {'class': 'form-horizontal'}}) }}
    {{ form_errors(book_form) }}

    <div class=\"row\">
        <div class=\"col-sm-4\">

            <div class=\"form-group row\">
                {{ form_label(book_form.name,  null, {'label_attr': {'class': 'col-sm-3 col-form-label'}}) }}
                <div class=\"col-sm-9\">
                    {{ form_widget(book_form.name, {'attr': {'class': 'form-control'}}) }}
                </div>
            </div>
            <div class=\"form-group row\">
                {{ form_label(book_form.price,  null, {'label_attr': {'class': 'col-sm-3 col-form-label'}}) }}
                <div class=\"col-sm-9\">
                    {{ form_widget(book_form.price, {'attr': {'class': 'form-control', 'style': 'width: 100px; display: inline;'}}) }}
                </div>
            </div>

            {{ form_widget(book_form.save, {'attr': {'class': 'btn btn-primary col-sm-offset-3'}}) }}
        </div>
    </div>


    {{ form_end(book_form) }}


    <script>
        jQuery( document ).ready(function() {

        });
    </script>

{% endblock %}

", "book/edit.html.twig", "/var/www/practise/tieto_bookstore/templates/book/edit.html.twig");
    }
}
