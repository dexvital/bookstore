<?php

/* security/login.html.twig */
class __TwigTemplate_e4df892e7346ce9b41e2c1c9d8bec346bebdbb74ab63dba8e6c25724cf7d955c extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 2);
        $this->blocks = array(
            'moduletitle' => array($this, 'block_moduletitle'),
            'style' => array($this, 'block_style'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_moduletitle($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "moduletitle"));

        // line 5
        echo "    Login
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_style($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "style"));

        // line 9
        echo "    <style>

    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <form class=\"form-horizontal\" action=\"";
        // line 18
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        echo "\" method=\"post\" name=\"form\">
                    <h2>Login</h2>
                    ";
        // line 20
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 20, $this->source); })())) {
            // line 21
            echo "                        <div class=\"alert alert-danger\">
                            ";
            // line 22
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 22, $this->source); })()), "messageKey", array()), twig_get_attribute($this->env, $this->source, (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 22, $this->source); })()), "messageData", array()), "security"), "html", null, true);
            echo "
                        </div>
                    ";
        }
        // line 25
        echo "                    <div class=\"form-group row\">
                        <label for=\"form_username\" class=\"col-sm-3 col-form-label required\">Username</label>
                        <div class=\"col-sm-9\">
                            <input type=\"text\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new Twig_Error_Runtime('Variable "last_username" does not exist.', 28, $this->source); })()), "html", null, true);
        echo "\" placeholder=\"Username\" class=\"form-control\"
                                   required=\"required\" name=\"_username\" id=\"form_username\">
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label for=\"form_password\" class=\"col-sm-3 col-form-label required\">Password</label>
                        <div class=\"col-sm-9\">
                            <input type=\"password\" placeholder=\"Password\" class=\"form-control\"
                                   required=\"required\" name=\"_password\" id=\"form_password\">
                        </div>
                    </div>
                    <button class=\"btn btn-primary col-sm-offset-3\" name=\"form[submit]\" id=\"form_submit\" type=\"submit\">Submit</button>
                </form>
            </div>
        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 28,  98 => 25,  92 => 22,  89 => 21,  87 => 20,  82 => 18,  76 => 14,  70 => 13,  60 => 9,  54 => 8,  46 => 5,  40 => 4,  15 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# app/Resources/views/user/login.html.twig #}
{% extends 'base.html.twig' %}

{% block moduletitle %}
    Login
{% endblock %}

{% block style %}
    <style>

    </style>
{% endblock %}
{% block body %}

    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-6\">
                <form class=\"form-horizontal\" action=\"{{ path('login') }}\" method=\"post\" name=\"form\">
                    <h2>Login</h2>
                    {% if error %}
                        <div class=\"alert alert-danger\">
                            {{ error.messageKey|trans(error.messageData, 'security') }}
                        </div>
                    {% endif %}
                    <div class=\"form-group row\">
                        <label for=\"form_username\" class=\"col-sm-3 col-form-label required\">Username</label>
                        <div class=\"col-sm-9\">
                            <input type=\"text\" value=\"{{ last_username }}\" placeholder=\"Username\" class=\"form-control\"
                                   required=\"required\" name=\"_username\" id=\"form_username\">
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label for=\"form_password\" class=\"col-sm-3 col-form-label required\">Password</label>
                        <div class=\"col-sm-9\">
                            <input type=\"password\" placeholder=\"Password\" class=\"form-control\"
                                   required=\"required\" name=\"_password\" id=\"form_password\">
                        </div>
                    </div>
                    <button class=\"btn btn-primary col-sm-offset-3\" name=\"form[submit]\" id=\"form_submit\" type=\"submit\">Submit</button>
                </form>
            </div>
        </div>
    </div>

{% endblock %}", "security/login.html.twig", "/var/www/practise/tieto_bookstore/templates/security/login.html.twig");
    }
}
